package com.klipcep.app

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF0D0B16)
private val Panel = Color(0xFF191626)
private val Purple = Color(0xFF9B7BFF)
private val Muted = Color(0xFFAAA5BC)
private val White = Color(0xFFF7F5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KlipCepApp(this) }
    }
}

data class DownloadEntry(val id: Long, val title: String, val url: String, val date: Long, val status: String)

@Composable
fun KlipCepApp(context: Context) {
    var url by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("Video bağlantını buraya yapıştır.") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val clipboard = LocalClipboardManager.current
    val history = remember(refresh) { readHistory(context) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = White) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Download, null) }, label = { Text("İndir") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Geçmiş") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Info, null) }, label = { Text("Hakkında") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Color(0xFF5E43C8))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("KlipCep", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Videolarını kolayca kaydet", color = Muted, fontSize = 13.sp)
                    }
                    Box(Modifier.size(40.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Shield, null, tint = Purple)
                    }
                }
                Spacer(Modifier.height(26.dp))
                when (selectedTab) {
                    0 -> {
                        Text("Video indir", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Desteklenen bir video dosyası bağlantısını yapıştır.", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(22.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("VİDEO BAĞLANTISI", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Spacer(Modifier.height(12.dp))
                                OutlinedTextField(value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://...", color = Muted) }, minLines = 2, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF39334D), cursorColor = Purple))
                                Spacer(Modifier.height(10.dp))
                                OutlinedButton(onClick = { url = clipboard.getText()?.text.orEmpty(); notice = "Pano kontrol edildi." }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                    Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(8.dp)); Text("Panodan yapıştır")
                                }
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = {
                                    val trimmed = url.trim()
                                    when {
                                        trimmed.isBlank() -> notice = "Önce bir bağlantı yapıştır."
                                        !trimmed.startsWith("https://") && !trimmed.startsWith("http://") -> notice = "Geçerli bir http veya https bağlantısı gir."
                                        isInstagramPage(trimmed) -> notice = "Bu bir Instagram sayfası bağlantısı. Bu sürüm yalnızca doğrudan video dosyası bağlantılarını indirir; Instagram erişim kısıtlamalarını aşmaz."
                                        else -> {
                                            try {
                                                val uri = Uri.parse(trimmed)
                                                val fileName = URLUtil.guessFileName(trimmed, null, "video/mp4")
                                                val request = DownloadManager.Request(uri)
                                                    .setTitle(fileName)
                                                    .setDescription("KlipCep video indiriyor")
                                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "KlipCep/$fileName")
                                                    .setAllowedOverMetered(true)
                                                    .setAllowedOverRoaming(false)
                                                val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                                val id = manager.enqueue(request)
                                                saveHistory(context, DownloadEntry(id, fileName, trimmed, System.currentTimeMillis(), "İndirme başlatıldı"))
                                                refresh++
                                                notice = "İndirme başlatıldı. Bildirimlerden durumunu takip edebilirsin."
                                            } catch (_: Exception) { notice = "İndirme başlatılamadı. Bağlantıyı kontrol edip tekrar dene." }
                                        }
                                    }
                                }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Color.White)) {
                                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("İndirmeyi başlat", fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(12.dp))
                                Text(notice, color = if (notice.startsWith("İndirme başlatıldı")) Color(0xFF8BE3B0) else Muted, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Text("Nasıl çalışır?", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        FeatureRow(Icons.Default.Link, "Bağlantıyı yapıştır", "Doğrudan video dosyasına giden bağlantıyı kullan.")
                        FeatureRow(Icons.Default.DownloadDone, "İndirmeyi takip et", "Android indirme bildirimi tamamlanma durumunu gösterir.")
                        FeatureRow(Icons.Default.Security, "Gizliliğe önem verir", "Instagram şifreni istemez ve özel hesapları aşmaz.")
                    }
                    1 -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("İndirme geçmişi", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Bu cihazda başlattığın indirmeler", color = Muted, fontSize = 13.sp) }
                            TextButton(onClick = { clearHistory(context); refresh++ }) { Text("Temizle") }
                        }
                        Spacer(Modifier.height(16.dp))
                        if (history.isEmpty()) EmptyHistory() else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(history.reversed(), key = { it.id }) { item ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(44.dp).background(Color(0xFF30264D), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.VideoFile, null, tint = Purple) }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(item.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(item.status, color = Muted, fontSize = 12.sp)
                                        }
                                        IconButton(onClick = { openDownload(context, item.id) }) { Icon(Icons.Default.OpenInNew, "İndirmeyi aç", tint = Purple) }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("KlipCep hakkında", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Sürüm 1.0.0", color = Purple, fontWeight = FontWeight.Bold)
                                Text("KlipCep, doğrudan video dosyası bağlantılarını Android'in indirme sistemiyle kaydetmek için hazırlanmış bir başlangıç uygulamasıdır.", color = White)
                                Text("Instagram sayfaları doğrudan video dosyası değildir. Bu uygulama Instagram'ın erişim kontrollerini aşmaz. Yalnızca indirme hakkına sahip olduğun içerikleri kaydet.", color = Muted)
                                Text("Reklamlar bu başlangıç sürümüne henüz eklenmedi.", color = Muted)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Panel, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Purple) }
        Spacer(Modifier.width(12.dp))
        Column { Text(title, color = White, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted, fontSize = 12.sp) }
    }
}

@Composable private fun EmptyHistory() {
    Column(Modifier.fillMaxWidth().padding(top = 72.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.History, null, tint = Purple, modifier = Modifier.size(34.dp)) }
        Spacer(Modifier.height(14.dp)); Text("Henüz indirme yok", color = White, fontWeight = FontWeight.Bold); Text("Başlattığın indirmeler burada görünecek.", color = Muted, fontSize = 13.sp)
    }
}

private fun isInstagramPage(value: String): Boolean = runCatching {
    val host = Uri.parse(value).host?.lowercase().orEmpty()
    host == "instagram.com" || host.endsWith(".instagram.com") || host == "www.instagram.com"
}.getOrDefault(false)

private fun readHistory(context: Context): List<DownloadEntry> {
    val raw = context.getSharedPreferences("klipcep", Context.MODE_PRIVATE).getString("history", "[]") ?: "[]"
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { DownloadEntry(it.optLong("id"), it.optString("title"), it.optString("url"), it.optLong("date"), it.optString("status")) } }
    }.getOrDefault(emptyList())
}

private fun saveHistory(context: Context, entry: DownloadEntry) {
    val all = (readHistory(context).filterNot { it.id == entry.id } + entry).takeLast(100)
    val arr = JSONArray()
    all.forEach { e -> arr.put(JSONObject().put("id", e.id).put("title", e.title).put("url", e.url).put("date", e.date).put("status", e.status)) }
    context.getSharedPreferences("klipcep", Context.MODE_PRIVATE).edit().putString("history", arr.toString()).apply()
}

private fun clearHistory(context: Context) { context.getSharedPreferences("klipcep", Context.MODE_PRIVATE).edit().remove("history").apply() }
private fun openDownload(context: Context, id: Long) {
    try {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val intent = Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (_: Exception) { }
}
